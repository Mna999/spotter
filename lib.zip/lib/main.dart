import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:spotter/core/theme/app_theme.dart';
import 'package:spotter/core/usecases/usecase.dart';
import 'package:spotter/features/auth/presentation/bloc/auth_bloc/auth_bloc.dart';
import 'package:spotter/features/auth/presentation/bloc/profile_bloc/profile_bloc.dart';
import 'package:spotter/features/auth/presentation/screens/home_screen.dart';
import 'package:spotter/features/auth/presentation/screens/onBoarding_screen.dart';
import 'package:spotter/features/auth/presentation/screens/sign_in_screen.dart';
import 'package:spotter/firebase_options.dart';
import 'package:spotter/injection_container.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (_) => sl<AuthBloc>()..add(SessionRestoreRequested()),
        ),
        BlocProvider<ProfileBloc>(create: (_) => sl<ProfileBloc>()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Spotter',
        theme: AppTheme.light,
        darkTheme: AppTheme.dark,
        themeMode: ThemeMode.dark,
        builder: (context, child) => ColoredBox(
          color: Theme.of(context).colorScheme.surface,
          child: SafeArea(top: false, child: child!),
        ),
        home: BlocBuilder<ProfileBloc, ProfileState>(
          builder: (context, profileState) {
            final profileBloc = context.read<ProfileBloc>();

            return BlocBuilder<AuthBloc, AuthState>(
              builder: (context, authState) {
                if (authState is Authenticated) {
                  profileBloc.add(
                    ProfileLoadRequested(
                      profileParams: ProfileParams(authState.userAccount.uid),
                    ),
                  );
                  if (profileState is OnBoardingNotCompleted) {
                    return const OnboardingScreen();
                  } else {
                    return const HomeScreen();
                  }
                } else {
                  return const SignInScreen();
                }
              },
            );
          },
        ),
      ),
    );
  }
}
